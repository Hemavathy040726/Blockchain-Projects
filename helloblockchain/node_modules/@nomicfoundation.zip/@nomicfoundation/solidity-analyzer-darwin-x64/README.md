# `@nomicfoundation/solidity-analyzer-darwin-x64`

This is the **x86_64-apple-darwin** binary for `@nomicfoundation/solidity-analyzer`
