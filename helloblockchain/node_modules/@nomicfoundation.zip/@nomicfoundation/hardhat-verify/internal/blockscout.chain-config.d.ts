import type { ChainConfig } from "../types";
export declare const builtinChains: ChainConfig[];
//# sourceMappingURL=blockscout.chain-config.d.ts.map