"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContractStatus = void 0;
var ContractStatus;
(function (ContractStatus) {
    ContractStatus["PERFECT"] = "perfect";
    ContractStatus["PARTIAL"] = "partial";
    ContractStatus["NOT_FOUND"] = "false";
})(ContractStatus = exports.ContractStatus || (exports.ContractStatus = {}));
//# sourceMappingURL=sourcify.types.js.map