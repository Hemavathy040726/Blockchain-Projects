import type { ChainConfig } from "../types";
export declare const builtinChains: ChainConfig[];
//# sourceMappingURL=chain-config.d.ts.map