export {};
//# sourceMappingURL=blockscout.d.ts.map