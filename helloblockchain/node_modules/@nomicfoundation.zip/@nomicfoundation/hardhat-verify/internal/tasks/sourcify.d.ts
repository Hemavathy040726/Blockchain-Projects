export {};
//# sourceMappingURL=sourcify.d.ts.map