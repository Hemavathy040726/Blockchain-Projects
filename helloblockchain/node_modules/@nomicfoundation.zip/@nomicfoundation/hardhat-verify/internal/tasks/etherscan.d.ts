export {};
//# sourceMappingURL=etherscan.d.ts.map