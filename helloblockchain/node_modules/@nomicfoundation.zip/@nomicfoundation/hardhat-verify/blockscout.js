"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Blockscout = void 0;
var blockscout_1 = require("./internal/blockscout");
Object.defineProperty(exports, "Blockscout", { enumerable: true, get: function () { return blockscout_1.Blockscout; } });
//# sourceMappingURL=blockscout.js.map