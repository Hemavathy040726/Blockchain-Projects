"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Sourcify = void 0;
var sourcify_1 = require("./internal/sourcify");
Object.defineProperty(exports, "Sourcify", { enumerable: true, get: function () { return sourcify_1.Sourcify; } });
//# sourceMappingURL=sourcify.js.map