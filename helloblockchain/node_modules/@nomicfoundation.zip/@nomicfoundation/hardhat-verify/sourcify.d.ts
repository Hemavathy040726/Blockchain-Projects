export { Sourcify } from "./internal/sourcify";
//# sourceMappingURL=sourcify.d.ts.map