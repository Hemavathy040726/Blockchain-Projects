export { Blockscout } from "./internal/blockscout";
