export { Etherscan } from "./internal/etherscan";
//# sourceMappingURL=etherscan.d.ts.map