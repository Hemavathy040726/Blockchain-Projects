"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Etherscan = void 0;
var etherscan_1 = require("./internal/etherscan");
Object.defineProperty(exports, "Etherscan", { enumerable: true, get: function () { return etherscan_1.Etherscan; } });
//# sourceMappingURL=etherscan.js.map