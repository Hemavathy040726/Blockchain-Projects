export { Blockscout } from "./internal/blockscout";
//# sourceMappingURL=blockscout.d.ts.map