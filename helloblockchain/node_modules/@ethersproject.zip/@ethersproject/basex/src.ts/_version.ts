export const version = "basex/5.8.0";
