export const version = "random/5.8.0";
//# sourceMappingURL=_version.js.map