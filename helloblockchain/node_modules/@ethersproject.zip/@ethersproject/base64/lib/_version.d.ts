export declare const version = "base64/5.8.0";
//# sourceMappingURL=_version.d.ts.map