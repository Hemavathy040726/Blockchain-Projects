export declare const version = "logger/5.8.0";
//# sourceMappingURL=_version.d.ts.map