export const version = "bignumber/5.8.0";
