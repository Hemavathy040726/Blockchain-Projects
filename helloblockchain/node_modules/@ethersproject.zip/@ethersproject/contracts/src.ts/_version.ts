export const version = "contracts/5.8.0";
