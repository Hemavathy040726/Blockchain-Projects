export declare const version = "keccak256/5.8.0";
//# sourceMappingURL=_version.d.ts.map