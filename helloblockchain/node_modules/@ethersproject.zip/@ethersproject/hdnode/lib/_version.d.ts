export declare const version = "hdnode/5.8.0";
//# sourceMappingURL=_version.d.ts.map