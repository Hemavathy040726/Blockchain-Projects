import _ec from "elliptic";
import EC = _ec.ec;

export { EC }
