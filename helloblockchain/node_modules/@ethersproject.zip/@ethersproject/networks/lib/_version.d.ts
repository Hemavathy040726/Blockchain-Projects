export declare const version = "networks/5.8.0";
//# sourceMappingURL=_version.d.ts.map