export declare function isCrowdsaleWallet(json: string): boolean;
export declare function isKeystoreWallet(json: string): boolean;
export declare function getJsonWalletAddress(json: string): string;
//# sourceMappingURL=inspect.d.ts.map