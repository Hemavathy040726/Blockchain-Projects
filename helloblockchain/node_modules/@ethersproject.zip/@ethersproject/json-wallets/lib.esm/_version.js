export const version = "json-wallets/5.8.0";
//# sourceMappingURL=_version.js.map