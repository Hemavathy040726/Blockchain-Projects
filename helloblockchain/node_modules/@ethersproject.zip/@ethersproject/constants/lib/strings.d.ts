export declare const EtherSymbol = "\u039E";
//# sourceMappingURL=strings.d.ts.map