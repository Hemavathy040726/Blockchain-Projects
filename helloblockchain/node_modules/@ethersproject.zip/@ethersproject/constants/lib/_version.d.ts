export declare const version = "constants/5.8.0";
//# sourceMappingURL=_version.d.ts.map