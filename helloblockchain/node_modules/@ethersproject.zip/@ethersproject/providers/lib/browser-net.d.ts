export declare function connect(): void;
//# sourceMappingURL=browser-net.d.ts.map