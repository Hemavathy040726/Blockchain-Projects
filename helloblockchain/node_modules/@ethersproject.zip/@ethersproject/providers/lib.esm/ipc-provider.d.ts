declare const IpcProvider: any;
export { IpcProvider };
//# sourceMappingURL=ipc-provider.d.ts.map