"use strict";
const IpcProvider = null;
export { IpcProvider };
//# sourceMappingURL=ipc-provider.js.map