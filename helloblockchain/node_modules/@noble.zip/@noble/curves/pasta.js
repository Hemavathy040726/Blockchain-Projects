"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.vesta = exports.pallas = void 0;
var misc_ts_1 = require("./misc.js");
Object.defineProperty(exports, "pallas", { enumerable: true, get: function () { return misc_ts_1.pallas; } });
Object.defineProperty(exports, "vesta", { enumerable: true, get: function () { return misc_ts_1.vesta; } });
//# sourceMappingURL=pasta.js.map