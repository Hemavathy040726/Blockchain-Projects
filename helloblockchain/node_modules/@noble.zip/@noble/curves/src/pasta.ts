export { pallas, vesta } from './misc.ts';
