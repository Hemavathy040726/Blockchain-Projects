export { pallas, vesta } from './misc.ts';
//# sourceMappingURL=pasta.d.ts.map