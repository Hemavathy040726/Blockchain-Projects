import "./type-extensions";
//# sourceMappingURL=index.d.ts.map