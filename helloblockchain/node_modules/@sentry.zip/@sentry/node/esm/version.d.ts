export declare const SDK_NAME = "sentry.javascript.node";
export declare const SDK_VERSION = "5.30.0";
//# sourceMappingURL=version.d.ts.map