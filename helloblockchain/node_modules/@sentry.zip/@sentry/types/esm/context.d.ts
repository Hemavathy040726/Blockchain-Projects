export declare type Context = Record<string, unknown>;
export declare type Contexts = Record<string, Context>;
//# sourceMappingURL=context.d.ts.map