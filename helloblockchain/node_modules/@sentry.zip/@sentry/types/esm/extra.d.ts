export declare type Extra = unknown;
export declare type Extras = Record<string, Extra>;
//# sourceMappingURL=extra.d.ts.map