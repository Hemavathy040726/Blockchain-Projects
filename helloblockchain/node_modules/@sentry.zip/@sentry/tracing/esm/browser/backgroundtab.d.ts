/**
 * Add a listener that cancels and finishes a transaction when the global
 * document is hidden.
 */
export declare function registerBackgroundTabDetection(): void;
//# sourceMappingURL=backgroundtab.d.ts.map