import { Metric, ReportHandler } from '../types';
export declare const bindReporter: (callback: ReportHandler, metric: Metric, po: PerformanceObserver | undefined, observeAllUpdates?: boolean | undefined) => () => void;
//# sourceMappingURL=bindReporter.d.ts.map