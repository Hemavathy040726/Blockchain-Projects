import { ReportHandler } from './types';
export declare const getTTFB: (onReport: ReportHandler) => void;
//# sourceMappingURL=getTTFB.d.ts.map