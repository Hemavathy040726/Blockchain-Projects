import { ReportHandler } from './types';
export declare const getCLS: (onReport: ReportHandler, reportAllChanges?: boolean) => void;
//# sourceMappingURL=getCLS.d.ts.map